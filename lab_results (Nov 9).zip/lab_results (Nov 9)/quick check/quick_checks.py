"""
QUICK CHECKS - run these first (about 15 minutes in total)

  A. Noise check      : 30 readings without moving -> how much SNR jitters
  B. Settling check   : move, wait 0 / 0.25 / 0.5 / 1 / 2 s, read -> shortest safe wait
  C. Frequency check  : 20 readings at each carrier (2.48 vs 2.49 GHz) -> antenna rating effect

Every test saves its own CSV in the folder "lab_results", named like
  2026-11-09_1905_A_noise_check_Tx20cm_2.49GHz.csv
Each CSV starts with "# " lines (title, date, settings), then one row per reading
with time_s (seconds since the test started) and clock_time.
Read it in Python with: pandas.read_csv(path, comment="#")

Put this file in the SAME folder as angle_snr_sweep.py (it needs the `labview`
package). The ESP32 must be running gimbal_serial_control.ino.
"""

import os
import time
import glob
from datetime import datetime

import numpy as np
import serial
import win32com.client

from labview.config import LinkConfig
from labview.agent import TxAgentRun, RxAgentRun, TxAgentStop, RxAgentStop
from labview.measure import SignalPowerMeasure, NoisePowerMeasure


# ------------------------------------------------------------
# SETTINGS - check these before every session
# ------------------------------------------------------------

COM_PORT = "COM3"          # ESP32 port: Device Manager -> Ports (COM & LPT)
TX_DISTANCE_CM = 20        # Tx to Rx distance used today
CARRIER_GHZ = 2.49         # carrier set in LabVIEW (test C asks again)
task_codename = "test-narrowband"
task_bandtype = "narrow"

HOME = (0, 0)              # pan, tilt (deg) where the antenna sits for A and C
AWAY = (60, 20)            # where test B moves to before coming back

N_NOISE = 30               # test A readings
SETTLE_WAITS_S = [0, 0.25, 0.5, 1.0, 2.0]   # test B waits to compare
SETTLE_REPEATS = 5         # test B repeats per wait
N_FREQ = 20                # test C readings per frequency

OUT_DIR = "lab_results"


# ------------------------------------------------------------
# GIMBAL (ESP32 over USB serial) - same protocol as angle_snr_sweep.py
# ------------------------------------------------------------

class Gimbal:
    def __init__(self, port):
        self.ser = serial.Serial(port, 115200, timeout=15)
        time.sleep(2.5)                 # opening the port restarts the ESP32
        self.ser.reset_input_buffer()
        self.ser.write(b"?\n")
        self._wait_ok()
        print("Gimbal connected on", port)

    def _wait_ok(self):
        while True:
            line = self.ser.readline().decode(errors="ignore").strip()
            if line == "":
                raise RuntimeError("No reply from ESP32. Check COM port and that the code is uploaded.")
            if line.startswith("ERR"):
                raise RuntimeError("ESP32 said: " + line)
            if line.startswith("OK"):
                parts = line.split()        # e.g. ['OK', 'P30.0', 'T-10.0']
                return float(parts[1][1:]), float(parts[2][1:])

    def move(self, pan_deg, tilt_deg):
        self.ser.write(f"P{pan_deg:.1f} T{tilt_deg:.1f}\n".encode())
        return self._wait_ok()

    def close(self):
        try:
            self.move(0, 0)
        finally:
            self.ser.close()


# ------------------------------------------------------------
# MEASUREMENT
# ------------------------------------------------------------

def measure_noise():
    """Tx off -> measure the noise floor -> Tx back on."""
    global noise_power_dbm
    TxAgentStop()
    time.sleep(0.5)
    noise_power_dbm = NoisePowerMeasure(labview, link_setup, link_opts)
    link_setup.noise_power_dbm = noise_power_dbm
    TxAgentRun()
    time.sleep(0.5)
    print(f"Noise power = {noise_power_dbm:.2f} dBm")
    return noise_power_dbm


def read_snr():
    """ONE raw SNR reading in dB (no averaging, so we see the true jitter)."""
    return SignalPowerMeasure(labview, link_setup, link_opts) - noise_power_dbm


# ------------------------------------------------------------
# SAVING
# ------------------------------------------------------------

def save_csv(code, title, columns, rows, extra=None, freq_ghz=None):
    """Write a CSV with a readable title block, then one row per reading."""
    os.makedirs(OUT_DIR, exist_ok=True)
    f = freq_ghz if freq_ghz is not None else CARRIER_GHZ
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M")
    path = os.path.join(OUT_DIR, f"{stamp}_{code}_Tx{TX_DISTANCE_CM}cm_{f}GHz.csv")
    with open(path, "w", newline="") as fh:
        fh.write(f"# Title: {title}\n")
        fh.write(f"# Date: {datetime.now():%Y-%m-%d %H:%M:%S}\n")
        fh.write(f"# Tx distance: {TX_DISTANCE_CM} cm | Carrier: {f} GHz | Noise floor: {noise_power_dbm:.2f} dBm\n")
        for k, v in (extra or {}).items():
            fh.write(f"# {k}: {v}\n")
        fh.write(",".join(columns) + "\n")
        for r in rows:
            fh.write(",".join(str(round(x, 4)) if isinstance(x, float) else str(x) for x in r) + "\n")
    print("Saved", path)
    return path


def clock():
    return datetime.now().strftime("%H:%M:%S")


# ------------------------------------------------------------
# TEST A - NOISE
# ------------------------------------------------------------

def test_noise():
    print("\n=== A. NOISE CHECK: antenna still, readings repeated ===")
    gimbal.move(*HOME)
    time.sleep(2.0)
    measure_noise()
    rows, t0 = [], time.time()
    for i in range(N_NOISE):
        snr = read_snr()
        rows.append([i + 1, round(time.time() - t0, 2), clock(), HOME[0], HOME[1], snr])
        print(f"  {i + 1:2d}/{N_NOISE}  SNR = {snr:.3f} dB")
    s = np.array([r[5] for r in rows])
    summary = f"mean {s.mean():.2f} dB, std {s.std(ddof=1):.3f} dB, peak-to-peak {s.max() - s.min():.2f} dB"
    print("Result:", summary)
    save_csv("A_noise_check", "Noise check - repeated SNR readings with the antenna not moving",
             ["n", "time_s", "clock_time", "pan_deg", "tilt_deg", "snr_db"], rows,
             {"Summary": summary, "Readings": N_NOISE})
    return s.std(ddof=1)


# ------------------------------------------------------------
# TEST B - SETTLING
# ------------------------------------------------------------

def test_settling(jitter_db):
    print("\n=== B. SETTLING CHECK: move away, come back, wait, read ===")
    measure_noise()
    rows, t0, trial = [], time.time(), 0
    for rep in range(SETTLE_REPEATS):
        for wait in SETTLE_WAITS_S:          # waits interleaved so slow drift hits all equally
            trial += 1
            gimbal.move(*AWAY)
            time.sleep(1.0)
            gimbal.move(*HOME)
            time.sleep(wait)
            snr = read_snr()
            rows.append([trial, rep + 1, wait, round(time.time() - t0, 2), clock(), HOME[0], HOME[1], snr])
            print(f"  repeat {rep + 1}  wait {wait:4.2f} s  SNR = {snr:.3f} dB")

    data = np.array([[r[2], r[7]] for r in rows])
    ref = data[data[:, 0] == max(SETTLE_WAITS_S), 1].mean()
    lines, best_wait = [], None
    print(f"\nReference (wait {max(SETTLE_WAITS_S)} s) = {ref:.2f} dB")
    print(" wait (s) | mean - ref (dB) | spread (dB)")
    for w in SETTLE_WAITS_S:
        v = data[data[:, 0] == w, 1]
        diff, spread = v.mean() - ref, v.std(ddof=1)
        ok = abs(diff) <= 0.25 and spread <= max(0.3, 1.5 * jitter_db)
        if ok and best_wait is None:
            best_wait = w
        lines.append(f"{w}s: diff {diff:+.2f}, spread {spread:.2f}")
        print(f" {w:8.2f} | {diff:+15.2f} | {spread:10.2f} {'OK' if ok else ''}")
    rec = f"{best_wait} s" if best_wait is not None else f"{max(SETTLE_WAITS_S)} s (none shorter was stable)"
    print("Recommended SETTLE_S =", rec)
    save_csv("B_settling_check", "Settling check - SNR read at different waits after the gimbal stops",
             ["trial", "repeat", "wait_s", "time_s", "clock_time", "pan_deg", "tilt_deg", "snr_db"], rows,
             {"Away position (pan, tilt)": AWAY, "Per wait": " | ".join(lines), "Recommended SETTLE_S": rec})


# ------------------------------------------------------------
# TEST C - FREQUENCY (2.48 vs 2.49 GHz)
# ------------------------------------------------------------

def test_frequency():
    print("\n=== C. FREQUENCY CHECK: same position, two carriers ===")
    print("Change the carrier in LabVIEW (BOTH Tx and Rx) when asked. The antenna does not move.")
    gimbal.move(*HOME)
    while True:
        ans = input("\nCarrier LabVIEW is set to NOW in GHz (e.g. 2.48), or Enter to finish: ").strip()
        if ans == "":
            break
        f = float(ans)
        measure_noise()
        rows, t0 = [], time.time()
        for i in range(N_FREQ):
            snr = read_snr()
            rows.append([i + 1, round(time.time() - t0, 2), clock(), f, HOME[0], HOME[1], snr])
            print(f"  {i + 1:2d}/{N_FREQ}  {f} GHz  SNR = {snr:.3f} dB")
        s = np.array([r[6] for r in rows])
        print(f"Result at {f} GHz: mean {s.mean():.2f} dB, std {s.std(ddof=1):.3f} dB")
        save_csv("C_frequency_check", f"Frequency check - SNR at {f} GHz, antenna not moving",
                 ["n", "time_s", "clock_time", "carrier_ghz", "pan_deg", "tilt_deg", "snr_db"], rows,
                 {"Summary": f"mean {s.mean():.2f} dB, std {s.std(ddof=1):.3f} dB"}, freq_ghz=f)

    # compare every frequency file saved today
    today = datetime.now().strftime("%Y-%m-%d")
    files = sorted(glob.glob(os.path.join(OUT_DIR, f"{today}_*_C_frequency_check_*.csv")))
    if files:
        print("\nToday's frequency results:")
        for p in files:
            with open(p) as fh:
                lines = [ln.strip().split(",") for ln in fh if ln.strip() and not ln.startswith("#")]
            col = lines[0].index("snr_db")
            vals = [float(r[col]) for r in lines[1:]]
            print(f"  {os.path.basename(p)}: mean {np.mean(vals):.2f} dB ({len(vals)} readings)")


# ------------------------------------------------------------
# RUN
# ------------------------------------------------------------

if __name__ == "__main__":
    print("QUICK CHECKS | Tx distance", TX_DISTANCE_CM, "cm | carrier", CARRIER_GHZ, "GHz")
    choice = input("Run which? [A]ll, or A / B / C (Enter = all): ").strip().upper() or "ALL"

    gimbal = Gimbal(COM_PORT)
    labview = win32com.client.Dispatch("LabVIEW.Application")
    link_setup, link_opts = LinkConfig(codename=task_codename, bandtype=task_bandtype)
    RxAgentRun()
    TxAgentRun()
    noise_power_dbm = float("nan")

    try:
        jitter = 0.25
        if choice in ("ALL", "A"):
            jitter = test_noise()
        if choice in ("ALL", "B"):
            test_settling(jitter)
        if choice in ("ALL", "C"):
            test_frequency()
    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        TxAgentStop()
        RxAgentStop()
        gimbal.close()
        print("Done. Files are in", os.path.abspath(OUT_DIR))
