"""
MAIN RUNS - after quick_checks.py

  1. Full angle sweep, 5 deg steps  (481 angles, ~20-25 min)  <- the rotation "ground truth"
  2. Pan cut at tilt 0, 2 deg steps (91 angles, ~4 min)       <- run once on-axis, once off-axis
  3. Rotation algorithms, repeated  (coarse-to-fine / lobing / Bayesian, ~2-5 min each)
     Runs your existing scripts unchanged, then saves each repeat as its own titled CSV
     with the time of every measurement added.

Every run saves a CSV in "lab_results", named like
  2026-11-09_1930_1_angle_sweep_5deg_Tx20cm_2.49GHz.csv
Each CSV starts with "# " lines (title, date, settings), then one row per measurement
with time_s (seconds since the run started) and clock_time.
Read it in Python with: pandas.read_csv(path, comment="#")

Put this file in the SAME folder as angle_snr_sweep.py and the fyp_ee_*.py scripts.
The ESP32 must be running gimbal_serial_control.ino.
"""

import os
import time
import runpy
from datetime import datetime, timedelta

import numpy as np
import serial
import win32com.client
import matplotlib.pyplot as plt

import labview.measure as lvm
from labview.config import LinkConfig
from labview.agent import TxAgentRun, RxAgentRun, TxAgentStop, RxAgentStop
from labview.measure import NoisePowerMeasure


# ------------------------------------------------------------
# SETTINGS - check these before every session
# ------------------------------------------------------------

COM_PORT = "COM3"          # ESP32 port (also forced onto the algorithm scripts in option 3)
TX_DISTANCE_CM = 20        # Tx to Rx distance used today
CARRIER_GHZ = 2.49         # carrier set in LabVIEW
task_codename = "test-narrowband"
task_bandtype = "narrow"

SETTLE_S = 1.0             # use the value quick_checks.py recommended
N_AVG = 3                  # readings averaged per angle

SWEEP_PAN = (-90, 90, 5)   # min, max, step (deg)
SWEEP_TILT = (-30, 30, 5)
CUT_PAN = (-90, 90, 2)     # pan cut at tilt 0
CUT_TILT = 0

ALGORITHMS = {             # option 3: script, the CSV it writes, readable name
    "1": ("fyp_ee_angle_coarse_to_fine.py", "angle_c2f_results.csv", "Coarse-to-fine angle search"),
    "2": ("fyp_ee_lobing_tracker.py", "lobing_results.csv", "Sequential lobing"),
    "3": ("fyp_ee_angle_bayesian.py", "angle_bayes_results.csv", "Bayesian optimisation (angles)"),
}

OUT_DIR = "lab_results"


# ------------------------------------------------------------
# GIMBAL (ESP32 over USB serial) - same protocol as angle_snr_sweep.py
# ------------------------------------------------------------

class Gimbal:
    def __init__(self, port):
        self.ser = serial.Serial(port, 115200, timeout=15)
        time.sleep(2.5)
        self.ser.reset_input_buffer()
        self.ser.write(b"?\n")
        self._wait_ok()
        print("Gimbal connected on", port)

    def _wait_ok(self):
        while True:
            line = self.ser.readline().decode(errors="ignore").strip()
            if line == "":
                raise RuntimeError("No reply from ESP32. Check COM port and that the code is uploaded.")
            if line.startswith("ERR"):
                raise RuntimeError("ESP32 said: " + line)
            if line.startswith("OK"):
                parts = line.split()
                return float(parts[1][1:]), float(parts[2][1:])

    def move(self, pan_deg, tilt_deg):
        self.ser.write(f"P{pan_deg:.1f} T{tilt_deg:.1f}\n".encode())
        return self._wait_ok()

    def close(self):
        try:
            self.move(0, 0)
        finally:
            self.ser.close()


# ------------------------------------------------------------
# HELPERS
# ------------------------------------------------------------

def clock():
    return datetime.now().strftime("%H:%M:%S")


def csv_path(code):
    os.makedirs(OUT_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M")
    return os.path.join(OUT_DIR, f"{stamp}_{code}_Tx{TX_DISTANCE_CM}cm_{CARRIER_GHZ}GHz.csv")


def write_csv(path, title, columns, rows, extra=None):
    with open(path, "w", newline="") as fh:
        fh.write(f"# Title: {title}\n")
        fh.write(f"# Date: {datetime.now():%Y-%m-%d %H:%M:%S}\n")
        fh.write(f"# Tx distance: {TX_DISTANCE_CM} cm | Carrier: {CARRIER_GHZ} GHz\n")
        for k, v in (extra or {}).items():
            fh.write(f"# {k}: {v}\n")
        fh.write(",".join(columns) + "\n")
        for r in rows:
            fh.write(",".join(str(round(x, 4)) if isinstance(x, float) else str(x) for x in r) + "\n")


def angles(lo, hi, step):
    a = np.arange(lo, hi + step / 2, step)
    return a[a <= hi]


def start_radio():
    global labview, link_setup, link_opts, noise_power_dbm
    labview = win32com.client.Dispatch("LabVIEW.Application")
    link_setup, link_opts = LinkConfig(codename=task_codename, bandtype=task_bandtype)
    RxAgentRun()
    noise_power_dbm = NoisePowerMeasure(labview, link_setup, link_opts)   # Tx off
    link_setup.noise_power_dbm = noise_power_dbm
    print(f"Noise power = {noise_power_dbm:.2f} dBm")
    TxAgentRun()


def measure_snr():
    readings = [lvm.SignalPowerMeasure(labview, link_setup, link_opts) for _ in range(N_AVG)]
    mean_mw = np.mean([10 ** (p / 10) for p in readings])
    return 10 * np.log10(mean_mw) - noise_power_dbm


# ------------------------------------------------------------
# 1 + 2. GRID SWEEP (serpentine, saves after every row)
# ------------------------------------------------------------

def grid_sweep(code, title, pans, tilts, extra):
    total = len(pans) * len(tilts)
    est_min = total * (SETTLE_S + 0.5 * N_AVG + 0.5) / 60
    print(f"\n=== {title} ===\n{len(pans)} pan x {len(tilts)} tilt = {total} angles, roughly {est_min:.0f} min")
    path = csv_path(code)
    columns = ["n", "time_s", "clock_time", "pan_cmd_deg", "tilt_cmd_deg", "pan_deg", "tilt_deg", "snr_db"]
    extra = {**extra, "Settle": f"{SETTLE_S} s", "Readings averaged per angle": N_AVG, "Noise floor": f"{noise_power_dbm:.2f} dBm"}

    gimbal = Gimbal(COM_PORT)
    rows, grid, t0, n = [], np.full((len(tilts), len(pans)), np.nan), time.time(), 0
    best = (-np.inf, None, None)
    try:
        for ti, tilt in enumerate(tilts):
            order = range(len(pans)) if ti % 2 == 0 else range(len(pans) - 1, -1, -1)
            for pi in order:
                pan = pans[pi]
                ap, at = gimbal.move(pan, tilt)
                time.sleep(SETTLE_S)
                snr = measure_snr()
                n += 1
                grid[ti, pi] = snr
                rows.append([n, round(time.time() - t0, 2), clock(), float(pan), float(tilt), ap, at, snr])
                if snr > best[0]:
                    best = (snr, ap, at)
                print(f"{n:4d}/{total}  pan {ap:6.1f}  tilt {at:6.1f}  SNR {snr:6.2f} dB   (best {best[0]:.2f})")
            write_csv(path, title + " (partial)", columns, rows, extra)    # nothing lost if it stops
    except KeyboardInterrupt:
        print("\nStopped by user - saving what was measured.")
    finally:
        gimbal.close()

    done = len(rows) == total
    write_csv(path, title if done else title + " (stopped early)", columns, rows,
              {**extra, "Best": f"{best[0]:.2f} dB at pan {best[1]}, tilt {best[2]} deg",
               "Total time": f"{(time.time() - t0) / 60:.1f} min", "Complete": done})
    print("Saved", path)

    if len(tilts) > 1:      # heatmap for the sweep
        P, T = np.meshgrid(pans, tilts)
        plt.figure(figsize=(8, 4))
        m = plt.pcolormesh(P, T, grid, shading="auto", cmap="viridis")
        plt.colorbar(m, label="SNR (dB)")
        plt.scatter(best[1], best[2], marker="x", s=90, color="red")
        plt.xlabel("Pan (deg)"); plt.ylabel("Tilt (deg)"); plt.title(title)
    else:                   # line plot for the pan cut
        plt.figure(figsize=(8, 3.5))
        plt.plot(pans, grid[0], marker="o", ms=3)
        plt.xlabel("Pan (deg)"); plt.ylabel("SNR (dB)"); plt.title(title); plt.grid(alpha=.3)
    plt.savefig(path.replace(".csv", ".png"), dpi=200, bbox_inches="tight")
    plt.close("all")
    print("Saved", path.replace(".csv", ".png"))


# ------------------------------------------------------------
# 3. RUN AN EXISTING ALGORITHM SCRIPT, THEN ARCHIVE ITS CSV WITH TIMES
# ------------------------------------------------------------

def run_algorithm(key, repeats):
    script, out_csv, name = ALGORITHMS[key]
    if not os.path.exists(script):
        print("Cannot find", script, "- put main_runs.py in the same folder.")
        return
    orig_measure, orig_show, orig_serial = lvm.SignalPowerMeasure, plt.show, serial.Serial

    for r in range(1, repeats + 1):
        input(f"\n{name}: repeat {r}/{repeats}. Press Enter to start (the gimbal will move)...")
        calls, t0 = [], [time.time()]

        def timed_measure(*a, **k):                  # logs the time of every SNR reading
            v = orig_measure(*a, **k)
            calls.append(time.time() - t0[0])
            return v

        lvm.SignalPowerMeasure = timed_measure
        plt.show = lambda *a, **k: None              # don't block on the script's plots
        serial.Serial = lambda port, *a, **k: orig_serial(COM_PORT, *a, **k)
        if os.path.exists(out_csv):
            os.remove(out_csv)
        t0[0] = time.time()
        try:
            g = runpy.run_path(script, run_name="__main__")
        except Exception as e:
            print("The script stopped with an error:", e)
            g = {}
        finally:
            lvm.SignalPowerMeasure, plt.show, serial.Serial = orig_measure, orig_show, orig_serial
            plt.close("all")
        total_s = time.time() - t0[0]

        if not os.path.exists(out_csv):
            print("No", out_csv, "was written - nothing to save for this repeat.")
            continue
        with open(out_csv) as fh:
            lines = [ln.strip() for ln in fh if ln.strip()]
        header, data = lines[0].split(","), [ln.split(",") for ln in lines[1:]]

        def tidy(x):                                 # 1.000000e+00 -> 1, 5.123456e+01 -> 51.2346
            try:
                v = float(x)
                return int(v) if v.is_integer() else round(v, 4)
            except ValueError:
                return x
        data = [[tidy(x) for x in d] for d in data]

        n_avg = int(g.get("N_AVG", 3))
        meas_t = calls[n_avg - 1::n_avg]             # time when each averaged measurement finished
        start_clock = datetime.fromtimestamp(t0[0])
        if len(meas_t) == len(data):
            cols = ["time_s", "clock_time"] + header
            rows = [[round(t, 2), (start_clock + timedelta(seconds=t)).strftime("%H:%M:%S")] + d
                    for t, d in zip(meas_t, data)]
            note = "time_s = when each measurement finished, from the start of the run"
        else:
            cols = header
            rows = data
            note = (f"script logged {len(data)} rows but took {len(meas_t)} measurements, "
                    f"so per-row times were not added. Measurement times (s): "
                    + " ".join(f"{t:.1f}" for t in meas_t))
        path = csv_path(f"3_{os.path.splitext(out_csv)[0]}_rep{r}")
        write_csv(path, f"{name} - repeat {r} of {repeats}", cols, rows,
                  {"Script": script, "Measurements": len(meas_t), "Total time": f"{total_s / 60:.1f} min",
                   "Settle (script)": f"{g.get('SETTLE_S', '?')} s", "Readings averaged (script)": n_avg, "Note": note})
        print("Saved", path)


# ------------------------------------------------------------
# MENU
# ------------------------------------------------------------

if __name__ == "__main__":
    print(f"MAIN RUNS | Tx distance {TX_DISTANCE_CM} cm | carrier {CARRIER_GHZ} GHz | settle {SETTLE_S} s")
    print(" 1  Full angle sweep, 5 deg (~20-25 min)")
    print(" 2  Pan cut at tilt 0, 2 deg (~4 min)")
    print(" 3  Rotation algorithm, repeated")
    choice = input("Choose 1 / 2 / 3: ").strip()

    if choice in ("1", "2"):
        start_radio()
        try:
            if choice == "1":
                grid_sweep("1_angle_sweep_5deg", "Full angle sweep - 5 deg steps",
                           angles(*SWEEP_PAN), angles(*SWEEP_TILT),
                           {"Pan range": SWEEP_PAN, "Tilt range": SWEEP_TILT})
            else:
                mount = input("Antenna mount for this cut (e.g. on-axis / off-axis): ").strip() or "unlabelled"
                offset = input("Antenna distance from the pan axis in cm (Enter to skip): ").strip() or "not given"
                grid_sweep(f"2_pan_cut_{mount.replace(' ', '-')}", f"Pan cut at tilt 0 - {mount} mount",
                           angles(*CUT_PAN), np.array([CUT_TILT]),
                           {"Antenna mount": mount, "Offset from pan axis (cm)": offset, "Pan range": CUT_PAN})
        finally:
            TxAgentStop()
            RxAgentStop()

    elif choice == "3":
        for k, (_, _, nm) in ALGORITHMS.items():
            print(f"   {k}  {nm}")
        key = input("Which algorithm? ").strip()
        reps = int(input("How many repeats? (Enter = 3) ").strip() or 3)
        if key in ALGORITHMS:
            run_algorithm(key, reps)
        else:
            print("Unknown choice.")
    print("Done. Files are in", os.path.abspath(OUT_DIR))
